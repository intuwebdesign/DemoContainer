﻿angular.module("umbraco").controller("Our.Umbraco.HeadingsController", function ($scope) {

    if ($scope.model.value === null) {
        $scope.model.value = "P";
    }

    // could read positions from defaultConfig
    $scope.headings = [
        {
            Name: "H1"
        },
        {
            Name: "H2"
        },
        {
            Name: "H3"
        },
        {
            Name: "H4"
        },
        {
            Name: "H5"
        },
        {
            Name: "H6"
        },
        {
            Name: "P"
        }
    ];
});